Concerns

ID | Concerns
----------- | ------------| 
CRN-1 | System will not crash while 100+ users are on it
CRN-2 | A experienced team must be made for the development and maintenance of the course management system
CRN-3 | Creating a functional and comprehensive initial structure for the course management system to be developed on
